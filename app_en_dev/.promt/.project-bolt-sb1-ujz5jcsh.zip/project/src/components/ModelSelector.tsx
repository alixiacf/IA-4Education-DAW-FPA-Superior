import React from 'react';
import type { Model } from '../types';

interface ModelSelectorProps {
  models: Model[];
  selectedModel: string;
  onSelect: (modelName: string) => void;
}

export function ModelSelector({
  models,
  selectedModel,
  onSelect,
}: ModelSelectorProps) {
  return (
    <div className="flex items-center space-x-3">
      <label htmlFor="model" className="text-gray-300">
        Model:
      </label>
      <select
        id="model"
        value={selectedModel}
        onChange={(e) => onSelect(e.target.value)}
        className="bg-gray-700 text-gray-200 rounded-md px-3 py-1.5 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        {models.map((model) => (
          <option key={model.name} value={model.name}>
            {model.name}
          </option>
        ))}
      </select>
    </div>
  );
}