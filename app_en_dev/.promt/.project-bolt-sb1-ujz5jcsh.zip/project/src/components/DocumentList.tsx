import React from 'react';
import { FileText } from 'lucide-react';
import type { Document } from '../types';

interface DocumentListProps {
  documents: Document[];
}

export function DocumentList({ documents }: DocumentListProps) {
  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <h2 className="text-xl font-semibold mb-4 text-gray-200">
        Uploaded Documents
      </h2>
      <div className="space-y-2">
        {documents.map((doc) => (
          <div
            key={doc.name}
            className="flex items-center space-x-3 p-3 bg-gray-700 rounded-md"
          >
            <FileText className="text-blue-400" />
            <div>
              <p className="text-gray-200">{doc.name}</p>
              <p className="text-sm text-gray-400">{doc.chunks} chunks</p>
            </div>
          </div>
        ))}
        {documents.length === 0 && (
          <p className="text-gray-400 text-center py-4">No documents uploaded</p>
        )}
      </div>
    </div>
  );
}