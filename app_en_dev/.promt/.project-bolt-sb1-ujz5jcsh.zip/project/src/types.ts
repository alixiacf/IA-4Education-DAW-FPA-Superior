export interface Model {
  name: string;
  modified_at: string;
  size: number;
}

export interface Document {
  name: string;
  chunks: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  sources?: string[];
}

export interface RagResponse {
  response: string;
  context: {
    sources: string[];
    count: number;
  };
}